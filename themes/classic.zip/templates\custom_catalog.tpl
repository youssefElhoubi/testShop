{extends file='page.tpl'}

{block name='page_title'}
    Custom Category Catalog
{/block}

{block name='page_content'}
    <div class="custom-catalog-wrapper">

        {* Custom Navigation Bar *}
        <nav class="custom-category-nav" style="margin-bottom: 20px; padding: 10px; background: #f6f6f6; border-radius: 4px;">
            <ul style="list-style: none; padding: 0; margin: 0; display: flex; flex-wrap: wrap; gap: 15px;">
                <li>
                    <a href="{$controller_url}" style="text-decoration: none; font-weight: {if $current_category == 0}bold{else}normal{/if}; text-transform: uppercase;">
                        All Products
                    </a>
                </li>
                {foreach from=$custom_categories item=category}
                    <li>
                        <a href="{$controller_url}?id_category={$category.id_category}" style="text-decoration: none; font-weight: {if $current_category == $category.id_category}bold{else}normal{/if};">
                            {$category.name}
                        </a>
                    </li>
                {/foreach}
            </ul>
        </nav>

        <div class="custom-product-grid">
            {foreach from=$custom_products item=product}

                <article class="custom-product-card">
                    {* ADDED: Display the image if it exists *}
                    {if $product.image_url}
                        <div class="product-image-container">
                            <img src="{$product.image_url}" alt="{$product.product_name}" class="custom-product-image">
                        </div>
                    {/if}

                    <h3>{$product.product_name}</h3>
                    <div class="reference">Ref: {$product.reference}</div>
                    <div class="category">{$product.category_name}</div>
                </article>

            {foreachelse}

                <div class="alert alert-warning" style="width: 100%;">
                    No products found in this category.
                </div>

            {/foreach}
        </div>

    </div>
{/block}